﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Engine
    {
        //private int capacity;
        public int Capacity { get; set; } = 1000;

        public double CapacityinCubicInches { get { return Capacity * 0.12; } }
    }
}
