﻿namespace CarLibrary
{
    public class Vehicle
    {
        private int wheelCount = 0;

        //public int GetWheelCount()
        //{
        //    return wheelCount;
        //}

        //public void SetWheelCount(int wheelCount)
        //{
        //    if (wheelCount < 0)
        //    {
        //        wheelCount = 0;
        //    }
        //    this.wheelCount = wheelCount;
        //}


        public int WheelCount
        {
            get { return wheelCount; }
            set {
                if (value < 0)
                {
                    value = 0;
                }
                wheelCount = value; 
            }
        }

        private Engine engine;

        public Engine PowerUnit
        {
            get { return engine; }
            set { 
                if (value == null)
                {
                    value = new Engine();
                }
                engine = value; 
            }
        }

        public virtual void MyFunc()
        {
            wheelCount++;
        }



    }
}
