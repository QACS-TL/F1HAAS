﻿using CarLibrary;

Vehicle v1 = new Vehicle();
v1.WheelCount = -5;

//v1.SetWheelCount(-5);
Console.WriteLine($"The vehicle has {v1.WheelCount} wheels.");

Vehicle v2;

Vehicle v = new Van();

v.MyFunc();