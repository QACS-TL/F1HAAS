﻿using WeatherMonitorUsingDelegate;

namespace WeatherMonitor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WeatherDataSubjectWithDelegate weatherData = new WeatherDataSubjectWithDelegate();


            weatherData.WeatherChanged += (float temperature, float humidity, float pressure) =>
            {
                Console.WriteLine($"BBC Weather Warning!: \n temp:{temperature}, humidity:{humidity}, pressure:{pressure} ");
            };

            weatherData.WeatherChanged += (float temperature, float humidity, float pressure) =>
            {
                Console.WriteLine($"\"Met Office Weather Warning!: \n temp:{temperature}, humidity:{humidity}, pressure:{pressure} ");
            };

            weatherData.SetMeasurements(27, 65, 1026f);
            weatherData.SetMeasurements(28, 70, 1031f);
        }
    }
}