﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPatternUsingDelegate
{
    // The 'Invoker' class
    public class RemoteControl
    {
        private LightController _onCommand;
        private LightController _offCommand;
        private LightController _toggleCommand;
        public RemoteControl(LightController onCommand, LightController offCommand, LightController toggleComand)
        {
            _onCommand = onCommand;
            _offCommand = offCommand;
            _toggleCommand = toggleComand;
        }

        public void PressOnButton() => _onCommand.Invoke();
        public void PressOffButton() => _offCommand.Invoke();
        public void PressToggleButton() => _toggleCommand.Invoke();
    }
}
