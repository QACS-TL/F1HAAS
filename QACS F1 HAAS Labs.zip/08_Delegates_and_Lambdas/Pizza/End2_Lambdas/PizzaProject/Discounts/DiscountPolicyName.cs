﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaProject
{
    public enum DiscountPolicyName
    {
        None,
        Cheapest_Is_Free,
        Five_Percent_Off_More_Than_50_Dollars,
        Five_Dollars_Off_StuffedCrust,
        Weekend_10_Percent_Off
    }
}
