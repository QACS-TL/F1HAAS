﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvFile_lab
{
    //internal class MovieIn
    //{
    //    public string Title { get; set; }
    //    public int ReleaseYear { get; set; }
    //    public string Genres { get; set; }
    //    public decimal Revenue { get; set; }
    //}

    internal class Movie
    {
        public string Title { get; set; }
        public int ReleaseYear { get; set; }
        public string Genres { get; set; }
        public decimal Revenue { get; set; }
        public string StreamedOn { get; set; }
    }
}
