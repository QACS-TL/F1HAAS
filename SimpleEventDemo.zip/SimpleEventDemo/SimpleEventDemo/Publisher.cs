﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleEventDemo
{
    // Define a class that publishes an event
    class Publisher
    {
        // Define an event using EventHandler
        public event EventHandler SomethingHappened;

        // Method to trigger the event
        public void TriggerEvent()
        {
            Console.WriteLine("Publisher: I'm about to trigger the event!");
            // Check if there are any subscribers, then raise the event
            SomethingHappened?.Invoke(this, EventArgs.Empty);
        }
    }
}
