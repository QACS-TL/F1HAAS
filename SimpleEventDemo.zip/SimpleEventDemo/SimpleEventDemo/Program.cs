﻿// Create a publisher
using SimpleEventDemo;

//Explanation:
//Publisher: The Publisher class declares an event SomethingHappened using EventHandler.
//Subscriber: The Subscriber class defines an event handler method OnSomethingHappened that will execute when the event is triggered.
//Event Subscription: In the Main method, instances of Subscriber subscribe to the Publisher's event using the += operator.
//Event Triggering: The TriggerEvent method in the Publisher class raises the event using SomethingHappened?.Invoke.
//Unsubscribing: One subscriber is removed using the -= operator, showing how to stop receiving event notifications.


var publisher = new Publisher();

// Create two subscribers
var subscriber1 = new Subscriber("Subscriber 1");
var subscriber2 = new Subscriber("Subscriber 2");

// Subscribe to the event
publisher.SomethingHappened += subscriber1.OnSomethingHappened;
publisher.SomethingHappened += subscriber2.OnSomethingHappened;

// Trigger the event
publisher.TriggerEvent();

// Unsubscribe one subscriber
publisher.SomethingHappened -= subscriber1.OnSomethingHappened;

// Trigger the event again
publisher.TriggerEvent();

Console.ReadLine();

