﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleEventDemo
{
    // Define a class that subscribes to the event
    class Subscriber
    {
        private string _name;

        public Subscriber(string name)
        {
            _name = name;
        }

        // Event handler method
        public void OnSomethingHappened(object sender, EventArgs e)
        {
            Console.WriteLine($"{_name}: I received the event!");
        }
    }
}
