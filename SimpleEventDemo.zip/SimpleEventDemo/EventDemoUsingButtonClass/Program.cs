﻿using EventDemoUsingButtonClass;

var button = new Button();

// Subscribe to the Click event
button.Click += Button_Click;

// Simulate clicking the button
button.OnClick();

// Unsubscribe from the Click event
button.Click -= Button_Click;

// Simulate clicking again
button.OnClick();


static void Button_Click(object sender, EventArgs e)
{
    Console.WriteLine("Program: Button was clicked!");
}