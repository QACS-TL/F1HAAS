﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemoUsingButtonClass
{
    internal class Button
    {
        // Define an event
        public event EventHandler Click;

        // Method to simulate clicking the button
        public void OnClick()
        {
            Console.WriteLine("Button: Clicked!");
            Click?.Invoke(this, EventArgs.Empty); // Raise the event
        }
    }
}
